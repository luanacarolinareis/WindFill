(function initControllerAutofillContent() {
  "use strict";

  const shared = globalThis.ControllerAutofillShared;

  if (!shared) {
    return;
  }

  let autoFillDone = false;
  let scheduled = false;
  let lastResult = null;
  let lastContextTarget = null;

  function profileSummary(profile) {
    return {
      id: profile.id,
      name: profile.name,
      matchPattern: profile.matchPattern,
      matchedPattern: profile.matchedPattern || "",
      autoSubmit: profile.autoSubmit
    };
  }

  async function getMatchingProfiles() {
    const [profiles, matchPreferences] = await Promise.all([
      shared.loadProfiles(),
      shared.loadMatchPreferenceSettings()
    ]);
    return shared.findMatchingProfiles(window.location.href, profiles, matchPreferences);
  }

  async function attemptFill(options) {
    const settings = options && typeof options === "object" ? options : {};
    const requestedProfileId = settings.profileId || null;
    const requestedMode = settings.mode || "auto";
    const profiles = await getMatchingProfiles();
    const candidates = requestedProfileId
      ? profiles.filter((profile) => profile.id === requestedProfileId)
      : profiles;

    if (candidates.length === 0) {
      lastResult = {
        ok: false,
        reason: "No matching profile for this page.",
        matchedProfiles: []
      };
      return lastResult;
    }

    for (const profile of candidates) {
      const result = requestedMode === "context"
        ? shared.fillProfileFromContext(profile, lastContextTarget || document.activeElement)
        : shared.fillProfile(profile);
      if (result.ok) {
        autoFillDone = true;
        lastResult = {
          ok: true,
          reason: result.reason,
          profileId: result.profileId,
          profileName: result.profileName,
          matchedProfiles: candidates.map(profileSummary)
        };
        return lastResult;
      }
    }

    lastResult = {
      ok: false,
      reason: "Matching profile found, but the login form is not visible yet.",
      matchedProfiles: candidates.map(profileSummary)
    };
    return lastResult;
  }

  function scheduleFill() {
    if (scheduled || autoFillDone) {
      return;
    }

    scheduled = true;
    window.setTimeout(async () => {
      scheduled = false;
      await attemptFill();
    }, 90);
  }

  function installMutationObserver() {
    const root = document.documentElement || document;
    if (!root) {
      return;
    }

    const observer = new MutationObserver(() => {
      if (!autoFillDone) {
        scheduleFill();
      }
    });

    observer.observe(root, {
      childList: true,
      subtree: true
    });

    window.setTimeout(() => observer.disconnect(), 30000);
  }

  async function sendStatus(sendResponse) {
    const matches = await getMatchingProfiles();
    sendResponse({
      ok: true,
      url: window.location.href,
      autoFillDone,
      lastResult,
      matchedProfiles: matches.map(profileSummary)
    });
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || typeof message.type !== "string") {
      return false;
    }

    if (message.type === "controller-autofill:getStatus") {
      sendStatus(sendResponse);
      return true;
    }

    if (message.type === "controller-autofill:fillNow") {
      attemptFill({ profileId: message.profileId || null }).then(sendResponse);
      return true;
    }

    if (message.type === "controller-autofill:contextFill") {
      attemptFill({
        profileId: message.profileId || null,
        mode: "context"
      }).then(sendResponse);
      return true;
    }

    if (message.type === "controller-autofill:testSelectors") {
      try {
        sendResponse({
          ok: true,
          url: window.location.href,
          result: shared.testProfileSelectors(message.profile || {}, document)
        });
      } catch (error) {
        sendResponse({
          ok: false,
          reason: "Could not test selectors on this page."
        });
      }
      return false;
    }

    return false;
  });

  document.addEventListener(
    "contextmenu",
    (event) => {
      if (event.target instanceof Element) {
        lastContextTarget = event.target;
      }
    },
    true
  );

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", scheduleFill, { once: true });
  } else {
    scheduleFill();
  }

  installMutationObserver();
})();
